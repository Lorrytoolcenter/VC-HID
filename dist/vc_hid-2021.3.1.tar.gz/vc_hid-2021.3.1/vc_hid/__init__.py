##import os
##lib_path = os.path.join(os.path.dirname(__file__), 'vc_hid.dll')
##lib = CDLL(lib_path)
